# kefu-exe

**概要**

使用electron打包换新视频会议，生成可安装程序，可以在Win7以上或mac上运行。

## 安装 ##

安装依赖包
```
npm install
```

## 运行 ##

运行脚本

```
npm start
```

## 打包 ##

打包脚本
```
npm run dist
```